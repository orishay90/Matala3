package com.example.matala3;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity2 extends AppCompatActivity {

    private SharedPreferences mayShare;
    private SharedPreferences.Editor editor;

    private Intent nextAcyvity3;
    private EditText userName;
    private EditText password;
    private EditText name;
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        mayShare=getSharedPreferences("saveMsyData",Context.MODE_PRIVATE);

        if((mayShare.contains("userName")||(mayShare.contains("password"))))//חילחל לחלחה יעויןוי לחלחלך
        {
            check(true, true, true,mayShare.getString(String.valueOf(userName),"null"));
        }
        else
        {
            goToNextPage();
        }


;


    }



    private void goToNextPage() {

        button = findViewById(R.id.button_next_page);
        userName = findViewById(R.id.edit_Text_userName);
        password = findViewById(R.id.edit_Text_passWord);
        name = findViewById(R.id.edit_Text_name);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean userNameOk = false, passwordOk = false, nameOk = false;
                if (userName.getText().toString().length() > 0) {
                    userNameOk = true;
                } else
                    userName.setError("הכנס שם משתמש");

                if (password.getText().toString().length() ==8) {
                    passwordOk = true;
                } else
                    password.setError("הכנס סיסמא מעל 8 תווים");

                if (name.getText().toString().length() > 0) {
                    nameOk = true;
                } else {
                    name.setError("הכנס את שמך");
                }
               check(userNameOk, passwordOk, nameOk,userName.getText().toString());

            }
        });
    }


    public void check(boolean userNameOk, boolean passwordOk, boolean nameOk,String user) {
        if (nameOk && passwordOk && userNameOk) {
            saveData();
            nextAcyvity3 = new Intent(Activity2.this, Activity3.class);
            nextAcyvity3.putExtra("userName",user.toString());
            startActivity(nextAcyvity3);
            finish();
        }

    }

public void saveData(){
        SharedPreferences.Editor editor=mayShare.edit();
        editor=mayShare.edit();
        editor.putString("userName", String.valueOf(userName));
        editor.putString("password", String.valueOf(password));
        editor.putString("name", String.valueOf(name));
        editor.apply();

   }

}
